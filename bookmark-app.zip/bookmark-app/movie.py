import os
import pymsgbox

from flask import redirect,flash
from flask import Flask
from flask import render_template
from flask import request
import sqlalchemy as db
from flask_sqlalchemy import SQLAlchemy

project_dir = os.path.dirname(os.path.abspath(__file__))
engine = db.create_engine("sqlite:///{}".format(os.path.join(project_dir, "CRUD.db")))
            
app = Flask(__name__)
@app.route('/', methods=["GET", "POST"])
def index():
   return render_template('movie.html')

@app.route('/details', methods=["GET", "POST"])
def details():
   return render_template('insert.html')   

@app.route("/list", methods=["POST"])
def listofmovies():
    try:
        connection = engine.connect()
        metadata = db.MetaData()
        mytable = db.Table('mytable', metadata, autoload=True, autoload_with=engine)
        movie = request.form.get("title")
        query = db.select([mytable]).where(mytable.columns.Ranking < 51)
        # print(query)
        ResultProxy = connection.execute(query) 
        ResultSet = ResultProxy.fetchall()
        # db.session.commit()
    except Exception as e:
        print("Couldn't show movies details.")
        print(e)
    # movies = mytable.query.all() 
    return render_template("listOfMovies.html",movies=ResultSet)  

@app.route('/add', methods=["GET", "POST"])
def add():
    movieAdded=None
    if request.form:
        try:
            Name = request.form.get("Name")
            Link = request.form.get("Link")
            Ranking = request.form.get("Ranking")
            Poster = request.form.get("Poster")
            Rating = request.form.get("Rating")
            connection = engine.connect()
            metadata = db.MetaData()
            mytable = db.Table('mytable', metadata, autoload=True, autoload_with=engine)
            query = db.insert(mytable).values(Name=Name, Rating=Rating, Ranking=Ranking, Poster=Poster, Link=Link) 
            ResultProxy = connection.execute(query)
            # print(movieAdded)
            return render_template("movie.html",movieAdded=Name)
        except Exception as e:
            print("Failed to add movie")
            print(e)
    # return redirect("/")        

@app.route('/Search', methods=["GET", "POST"])
def home():
    movies = None
    if request.form:
        try:
            connection = engine.connect()
            metadata = db.MetaData()
            mytable = db.Table('mytable', metadata, autoload=True, autoload_with=engine)
            movie = request.form.get("title")
            query = db.select([mytable]).where(mytable.columns.Name==movie)
            # print(query)
            ResultProxy = connection.execute(query) 
            ResultSet = ResultProxy.fetchall()
           
        except Exception as e:
            print("Failed to Serch movie")
            print(e)
    if len(ResultSet)>0:
        return render_template("table.html",movies=ResultSet)
    else:
        return render_template("movie.html",movies="empty")
    # return render_template("table.html",movies=ResultSet)

@app.route("/update", methods=["POST"])
def update():
    updateDetails=None
    try:
        connection = engine.connect()
        metadata = db.MetaData()
        mytable = db.Table('mytable', metadata, autoload=True, autoload_with=engine)    
        newtitle = request.form.get("newtitle")
        oldtitle = request.form.get("oldtitle")
        # print(newtitle,oldtitle)
        newRating = request.form.get("newRating")
        oldRating = request.form.get("oldRating")
        query = db.update(mytable).values(Name = newtitle, Rating = newRating)
        query = query.where(mytable.columns.Name == oldtitle and mytable.columns.Rating == oldRating)
        ResultProxy = connection.execute(query)
        return render_template("movie.html",updateDetails=newtitle)
        # db.session.commit()
    except Exception as e:
        print("Couldn't update movie details")
        print(e)
    # movies = mytable.query.all() 
       

@app.route("/delete", methods=["POST"])
def delete():
    deletedMovie = None
    try:
        print("inside try")
        title = request.form.get("title")
        # print(title)
        connection = engine.connect()
        metadata = db.MetaData()
        mytable = db.Table('mytable', metadata, autoload=True, autoload_with=engine)
        query = db.delete(mytable)
        query = query.where(mytable.columns.Name == title)
        # print(query)
        results = connection.execute(query)
        # print(results)
        # db.session.commit()
    except Exception as e:
        print("Couldn't delete movie details")
        print(e)
    return render_template("movie.html",deletedMovie=title)

if __name__ == "__main__":
    app.run(debug=True)