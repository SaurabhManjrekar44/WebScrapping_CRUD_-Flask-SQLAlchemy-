import argparse
 

import pandas
from selenium import webdriver
from selenium.webdriver.chrome.webdriver import WebDriver
import datetime
import os
from sqlalchemy import create_engine


# ***** Running in Chrome Browser ******#
ap = argparse.ArgumentParser()
ap.add_argument("-n", "--search", required=True,help="search")
args = vars(ap.parse_args())

browser: WebDriver = webdriver.Chrome("chromedriver.exe")

browser.implicitly_wait(2)
browser.maximize_window()

dirName = 'CSV'
dirName1 = 'JSON'

if os.path.exists(dirName):
    print("")
else:
    os.mkdir(dirName)

if os.path.exists(dirName1):
    print("")
else:
    os.mkdir(dirName1)

browser.get('https://www.imdb.com/')
browser.find_element_by_xpath("//*[@id='navTitleMenu']/span").click()
browser.implicitly_wait(3)
if (args["search"]) in ['Best Films','Best Films Link','Film Poster','Best Films Poster','Movies with five details']:
    browser.find_element_by_xpath("//div[@class='subNavListContainer']/descendant::a[text()='Top Rated Movies']").click()
elif (args["search"]) in ['Best Indian Films','Best Indian Films Link','Indian Film Poster','Best Indian Films Poster']:     
    browser.find_element_by_xpath("//div[@class='subNavListContainer']/descendant::a[text()='Top Rated Indian Movies']").click()    
    # browser.find_element_by_xpath("//div[@class='subNavListContainer']/descendant::a[text()='{}']".format(args["selection"])).click()
elif (args["search"]) in ['Most Popular Movies']:
    browser.find_element_by_xpath("//div[@class='subNavListContainer']/descendant::a[text()='Most Popular Movies']").click()
movies = browser.find_elements_by_xpath("//tbody[@class='lister-list']/tr/td[2]/a")

if len(movies) != 0:
    #Names, Ranking and Rating of Best 250 films
    if (args["search"]) in ['Best Films','Best Indian Films',]:
        DFExcelWritter = pandas.DataFrame(index=range(1, len(movies) + 1), columns=['Ranking','Name', 'Rating'])
        for index in range(1, len(movies)+1):
            
                DFExcelWritter['Ranking'][index] = index
                DFExcelWritter['Name'][index] = browser.find_element_by_xpath(
                    "//tbody[@class='lister-list']/tr["+str(index)+"]/td[2]/a").text
                DFExcelWritter['Rating'][index] = browser.find_element_by_xpath(
                    "//tbody[@class='lister-list']/tr["+str(index)+"]/td[3]/strong").text
                print(DFExcelWritter)            
        if len(DFExcelWritter) > 0:
            DFExcelWritter.to_csv("CSV\\"+(args["search"])+".csv")

            json_records = DFExcelWritter.to_json(orient='records')

            
            #get current working directory
            path = os.getcwd()

            #open, write, and close the file
            f = open("JSON" + "\\"+(args["search"])+".json","w")
            f.write(json_records)
            f.close()
    #Links along with names of Best 250 films         
    if (args["search"]) in ['Best Films Link','Best Indian Films Link']:
        DFExcelWritter = pandas.DataFrame(index=range(1, len(movies) + 1), columns=['Ranking','Name', 'Link', 'Rating'])
        for index in range(1, len(movies)+1):
            
                DFExcelWritter['Ranking'][index] = index
                DFExcelWritter['Name'][index] = browser.find_element_by_xpath(
                    "//tbody[@class='lister-list']/tr["+str(index)+"]/td[2]/a").text
                DFExcelWritter['Link'][index] = browser.find_element_by_xpath(
                    "//tbody[@class='lister-list']/tr["+str(index)+"]/td[2]/a").get_attribute('href')
                DFExcelWritter['Rating'][index] = browser.find_element_by_xpath(
                    "//tbody[@class='lister-list']/tr["+str(index)+"]/td[3]/strong").text
                print(DFExcelWritter)
        if len(DFExcelWritter) > 0:
            
            DFExcelWritter.to_csv("CSV\\"+(args["search"])+".csv")

            json_records = DFExcelWritter.to_json(orient='records')

            
            #get current working directory
            path = os.getcwd()

            #open, write, and close the file
            f = open("JSON" + "\\"+(args["search"])+".json","w")
            f.write(json_records)
            f.close()

     #Full Size Poster along with names of film      
    if (args["search"]) in ['Film Poster','Indian Film Poster']:
        browser.find_element_by_xpath("//tbody[@class='lister-list']/tr[1]/td[2]/a").click()
        DFExcelWritter = pandas.DataFrame(index=range(1, 2), columns=['Name', 'Poster', 'Rating'])
        for index in range(1, 2):
                # print("123")
                DFExcelWritter['Name'][index] = browser.find_element_by_xpath("//div/h1").get_attribute("innerText")
                DFExcelWritter['Poster'][index] = browser.find_element_by_xpath("//div[@class='poster']/a/img").get_attribute("src")
                DFExcelWritter['Rating'][index] = browser.find_element_by_xpath("//span[@itemprop='ratingValue']").text
                print(DFExcelWritter)
        if len(DFExcelWritter) > 0:
            
            DFExcelWritter.to_csv("CSV\\"+(args["search"])+".csv")

            json_records = DFExcelWritter.to_json(orient='records')

            
            #get current working directory
            path = os.getcwd()

            #open, write, and close the file
            f = open("JSON" + "\\"+(args["search"])+".json","w")
            f.write(json_records)
            f.close()   
    #Poster along with Name of all the films in the list                      
    if (args["search"]) in ['Best Films Poster','Best Indian Films Poster']:
        DFExcelWritter = pandas.DataFrame(index=range(1, len(movies) + 1), columns=['Ranking','Name', 'Poster', 'Rating'])
        for index in range(1, len(movies)+1):
            
                DFExcelWritter['Ranking'][index] = index
                DFExcelWritter['Name'][index] = browser.find_element_by_xpath(
                    "//tbody[@class='lister-list']/tr["+str(index)+"]/td[2]/a").text
                DFExcelWritter['Poster'][index] = browser.find_element_by_xpath(
                    "//tbody[@class='lister-list']/tr["+str(index)+"]/td[1]/a/img").get_attribute('src')
                DFExcelWritter['Rating'][index] = browser.find_element_by_xpath(
                    "//tbody[@class='lister-list']/tr["+str(index)+"]/td[3]/strong").text
                print(DFExcelWritter)
        if len(DFExcelWritter) > 0:
            
            DFExcelWritter.to_csv("CSV\\"+(args["search"])+".csv")

            json_records = DFExcelWritter.to_json(orient='records')

            
            #get current working directory
            path = os.getcwd()

            #open, write, and close the file
            f = open("JSON" + "\\"+(args["search"])+".json","w")
            f.write(json_records)
            f.close()
    #Poster along with Name of all the films in the list                      
    if (args["search"]) in ['Most Popular Movies']:
        DFExcelWritter = pandas.DataFrame(index=range(1, len(movies) + 1), columns=['Ranking','Name', 'Poster'])
        for index in range(1, len(movies)+1):
            
                DFExcelWritter['Ranking'][index] = index
                DFExcelWritter['Name'][index] = browser.find_element_by_xpath(
                    "//tbody[@class='lister-list']/tr["+str(index)+"]/td[2]/a").text
                DFExcelWritter['Poster'][index] = browser.find_element_by_xpath(
                    "//tbody[@class='lister-list']/tr["+str(index)+"]/td[1]/a/img").get_attribute('src')
                print(DFExcelWritter)    
        if len(DFExcelWritter) > 0:
            
            DFExcelWritter.to_csv("CSV\\"+(args["search"])+".csv")

            json_records = DFExcelWritter.to_json(orient='records')

            
            #get current working directory
            path = os.getcwd()

            #open, write, and close the file
            f = open("JSON" + "\\"+(args["search"])+".json","w")
            f.write(json_records)
            f.close()

    #Best 250 movies details for CRUD database                     
    if (args["search"]) in ['Movies with five details']:
        DFExcelWritter = pandas.DataFrame(index=range(1, len(movies) + 1), columns=['Ranking','Name','Link', 'Poster', 'Rating'])
        for index in range(1, len(movies)+1):
            
                DFExcelWritter['Ranking'][index] = index
                DFExcelWritter['Name'][index] = browser.find_element_by_xpath(
                    "//tbody[@class='lister-list']/tr["+str(index)+"]/td[2]/a").text
                DFExcelWritter['Link'][index] = browser.find_element_by_xpath(
                    "//tbody[@class='lister-list']/tr["+str(index)+"]/td[2]/a").get_attribute('href')
                DFExcelWritter['Poster'][index] = browser.find_element_by_xpath(
                    "//tbody[@class='lister-list']/tr["+str(index)+"]/td[1]/a/img").get_attribute('src')
                DFExcelWritter['Rating'][index] = browser.find_element_by_xpath(
                    "//tbody[@class='lister-list']/tr["+str(index)+"]/td[3]/strong").text 
                print(DFExcelWritter)     

        if len(DFExcelWritter) > 0:
            
            DFExcelWritter.to_csv("CSV\\"+(args["search"])+".csv")

            json_records = DFExcelWritter.to_json(orient='records')

            
            #get current working directory
            path = os.getcwd()

            #open, write, and close the file
            f = open("JSON" + "\\"+(args["search"])+".json","w")
            f.write(json_records)
            f.close()    

            df = pandas.read_csv("CSV\\"+(args["search"])+".csv")
 
            project_dir = os.path.dirname(os.path.abspath(__file__))
            engine = create_engine("sqlite:///{}".format(os.path.join(project_dir, "CRUD.db")))
            df.to_sql('mytable', engine)    
    

browser.close()
